package static

var Admin = "admin"

var ValidTokenDays = 30
