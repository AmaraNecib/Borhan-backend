-- name: CreateUser :exec
INSERT INTO Users (email, password)
VALUES ($1, $2);
-- name: GetUserByEmail :one
SELECT * FROM Users WHERE email = $1;

-- name: GetAllClinics :many
SELECT * FROM Clinics offset $1 limit $2;