package types

type Heart struct {
	FirstName   string `json:"first_name"`
	LastName    string `json:"last_name"`
	NationalId  string `json:"national_id"`
	DateOfFirth string `json:"date_of_birth"`
}
type Login struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}
