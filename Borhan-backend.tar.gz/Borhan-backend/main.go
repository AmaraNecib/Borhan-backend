package main

import (
	"context"
	"fmt"
	"log"

	"github.com/AmaraNecib/Borhan-backend/DB"
	database "github.com/AmaraNecib/Borhan-backend/Database"
	"github.com/AmaraNecib/Borhan-backend/api"
)

func main() {
	dbConn, err := database.ConnectToDB()
	if err != nil {
		log.Fatalf("Could not connect to the database: %v", err)
	}
	defer dbConn.Close()

	// Create a new instance of the generated queries
	queries := DB.New(dbConn)
	_, err = api.Init(queries)
	if err != nil {
		panic(err)
	} // Assuming you have generated the db package
	tables, err := queries.GetTables(context.Background())
	if err != nil {
		log.Fatal(err)
	}

	// Print the table names
	for idx, table := range tables {
		fmt.Println(idx, table)
	}
	defer dbConn.Close()
}
